<script>
    function calculate(operation) {
        const num1 = document.getElementById('num1').value;
        const num2 = document.getElementById('num2').value;
        const resultDiv = document.getElementById('result');

        if (num1 === '' || num2 === '') {
            resultDiv.innerText = 'Please enter both numbers';
            resultDiv.style.backgroundColor = '#e74c3c';
            return;
        }

        fetch(`/${operation}?a=${num1}&b=${num2}`)
            .then(response => response.text())
            .then(result => {
                resultDiv.innerText = `Result: ${result}`;
                resultDiv.style.backgroundColor = '#2ecc71';
            })
            .catch(error => {
                resultDiv.innerText = `Error: ${error.message}`;
                resultDiv.style.backgroundColor = '#e74c3c';
            });
    }
</script>